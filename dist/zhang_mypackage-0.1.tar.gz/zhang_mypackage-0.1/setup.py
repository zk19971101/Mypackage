from setuptools import setup

setup(
    name='zhang_mypackage',
    version=0.1,
    description="my first package",
    url="#",
    author="zhangkai",
    author_email="2252177837@qq.com",
    liscense="szu",
    packages=['mypackage'],
    zip_safe=False
)