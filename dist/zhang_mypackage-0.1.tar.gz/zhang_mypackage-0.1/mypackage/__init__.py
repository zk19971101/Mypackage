from .functions import sum, power, average
from .greet import SayHello
import os
from collections import Counter