#greet.py
def SayHello(name):
    print("Hello ", name)
